package com.nopcommerce.testCases;

public class TC005_Dunny {

	public static void main(String[] args) {
	//It is my new test case...

	}

}
