package com.nopcommerce.testCases;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.nopcommerce.pageObjects.LoginPage;
import com.nopcommerce.testBase.BaseClass;

public class TC_LoginTest_001 extends BaseClass{

	@Test
	public void loginTest() throws IOException, InterruptedException
	{
		logger.info("************** Starting TC_LoginTest_001  *************");
		driver.get(configProObj.getProperty("baseURL"));
		LoginPage lp=new LoginPage(driver);
		
		logger.info("***********  Proving user data  *************");
		lp.setUserName(configProObj.getProperty("useremail"));
		lp.setPassword(configProObj.getProperty("password"));
		lp.clickLogin();
		
		logger.info("************* Verifying login ********");
		String exp_title="Dashboard / nopCommerce administration";
		String act_title=driver.getTitle();
		
		if(exp_title.equals(act_title))
		{
			logger.info("********* Login is Passed********");
			Assert.assertTrue(true);
		}
		else
		{
			captureScreen(driver,"loginTest"); // call this method on failure
			Thread.sleep(3000);
			logger.warn("********* Login is Failed ********");
			Assert.assertTrue(false);
		}
		
		logger.info("************** Finished TC_LoginTest_001  *************");
	}
	
	
}
