
public class Test1 {

	public static void main(String[] args) {

		String hungry = "yes";

		if (hungry == "yes")
			System.out.println("eat something....");
		else {
			System.out.println("Do work.......");
		}

	}
}
